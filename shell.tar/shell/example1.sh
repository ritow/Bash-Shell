#! /bin/bash
# Description: this script is used to test whether the input file is a tar file

#echo $# # print the parameter numbers
#echo $0 # print the filename
#echo $1 # print the first paramters
echo $#
filename=$1
echo $filename
