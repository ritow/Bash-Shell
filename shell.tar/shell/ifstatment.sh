#! /bin/bash
test='122'
if [ $test == '122' ]
then
	echo '122'
else
	echo '211'
fi




